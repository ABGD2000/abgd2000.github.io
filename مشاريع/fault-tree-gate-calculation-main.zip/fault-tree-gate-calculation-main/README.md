# fault-tree-gate-calculation
Simple Python program which calculates OR- &amp; AND-Gates, based on given basicevents of repairable systems.
